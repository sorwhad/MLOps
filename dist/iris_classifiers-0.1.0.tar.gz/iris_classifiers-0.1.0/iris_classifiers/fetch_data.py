from sklearn import datasets

def get_iris_data(): 
    iris = datasets.load_iris()
    return iris 