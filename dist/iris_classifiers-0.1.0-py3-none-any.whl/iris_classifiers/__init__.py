__version__ = "1.0.0"

__all__ = ['classify', 'fetch_data']